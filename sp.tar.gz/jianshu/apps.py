from django.apps import AppConfig


class JianshuConfig(AppConfig):
    name = 'jianshu'
